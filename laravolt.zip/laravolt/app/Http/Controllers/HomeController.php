<?php

namespace App\Http\Controllers;

use App\Models\Province;
use App\Models\Cities;
use Indonesia;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $province = Indonesia::allProvinces();
        return view('welcome',['province' => $province]);
    }

    public function province()
    {
        $prov = Indonesia::allProvinces();
        return response()->json($prov);
    }
    public function city($provinceId)
    {
        $city = Indonesia::findProvince($provinceId, $with = ['cities']);
        return response()->json($city);
    }

    public function district($cityId)
    {
        $district = Indonesia::findCity($cityId, $with = ['districts']);
        return response()->json($district);
    }

    public function villages($districtId)
    {
        $villages = Indonesia::findDistrict($districtId, $with = ['villages']);
        return response()->json($villages);
    }
}
